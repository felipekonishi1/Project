#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "compromisso.h"

void menu() {
    printf("\nMenu:\n");
    printf("1. Gerar entrada aleatória (entrada.csv)\n");
    printf("2. Ordenar por ano (Insertion Sort)\n");
    printf("3. Ordenar por ano (Heap Sort)\n");
    printf("4. Sair\n");
    printf("Escolha uma opcao: ");
}

int main() {
    srand(time(NULL)); //inicializar o srand

    int opcao;
    do {
        menu();
        scanf("%d", &opcao);
        
        switch (opcao) {                //switch case do progrmaa
            case 1: {
                int quantidadeCompromissos;
                printf("Informe a quantidade de compromissos: ");
                scanf("%d", &quantidadeCompromissos);
                gerarEntradaAleatoria(quantidadeCompromissos);
                break;
            }
            case 2: {
                int n;
                printf("Informe a quantidade de compromissos: ");
                scanf("%d", &n);
                Compromisso *compromissos = malloc(n * sizeof(Compromisso));
                if (compromissos == NULL) {
                    printf("Erro ao alocar memória.\n");
                    break;
                }
                FILE *arquivo = fopen("entrada.csv", "r");
                if (arquivo == NULL) {
                    printf("Erro ao abrir o arquivo para leitura.\n");
                    free(compromissos);
                    break;
                }
                for (int i = 0; i < n; i++) {
                    fscanf(arquivo, "%d;%d;%d;%d;%d;%f;%50[^\n]\n", &compromissos[i].ano, &compromissos[i].mes,
                           &compromissos[i].dia, &compromissos[i].hora, &compromissos[i].minuto,
                           &compromissos[i].duracao, compromissos[i].nome);
                }
                fclose(arquivo);
                long long comparacoes = 0;
                double tempo = 0.0;
                ordenarPorAnoInsertionSort(compromissos, n, &comparacoes, &tempo);
                printf("Tempo de execucao do Insertion Sort: %.6f segundos\n", tempo);
                printf("Numero de comparacoes do Insertion Sort: %lld\n", comparacoes);
                free(compromissos);
                break;
            }
            case 3: {
                int n;
                printf("Informe a quantidade de compromissos: ");
                scanf("%d", &n);
                Compromisso *compromissos = malloc(n * sizeof(Compromisso));
                if (compromissos == NULL) {
                    printf("Erro ao alocar memória.\n");
                    break;
                }
                FILE *arquivo = fopen("entrada.csv", "r");
                if (arquivo == NULL) {
                    printf("Erro ao abrir o arquivo para leitura.\n");
                    free(compromissos);
                    break;
                }
                for (int i = 0; i < n; i++) {
                    fscanf(arquivo, "%d;%d;%d;%d;%d;%f;%50[^\n]\n", &compromissos[i].ano, &compromissos[i].mes,
                           &compromissos[i].dia, &compromissos[i].hora, &compromissos[i].minuto,
                           &compromissos[i].duracao, compromissos[i].nome);
                }
                fclose(arquivo);
                long long comparacoes = 0;
                double tempo = 0.0;
                ordenarPorAnoHeapSort(compromissos, n, &comparacoes, &tempo);
                printf("Tempo de execucao do Heap Sort: %.6f segundos\n", tempo);
                printf("Numero de comparacoes do Heap Sort: %lld\n", comparacoes);
                free(compromissos);
                break;
            }
            case 4:
                printf("Saindo...\n");
                break;
            default:
                printf("Opcao invalida!\n");
        }
    } while (opcao != 4);

    return 0;
}