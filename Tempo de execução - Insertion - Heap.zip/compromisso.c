#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "compromisso.h"

//Função para imprimir compromisso
void imprimirCompromisso(Compromisso *compromisso) {
    printf("%d;%d;%d;%d;%d;%.1f;%s\n", compromisso->ano, compromisso->mes, compromisso->dia,
           compromisso->hora, compromisso->minuto, compromisso->duracao, compromisso->nome);
}

void gerarCompromissoAleatorio(Compromisso *compromisso, const char *compromissos[], int num_compromissos) {
    compromisso->ano = rand() % 14 + 2010; //Ano entre 2010 e 2023
    compromisso->mes = rand() % 12 + 1;    //Mês entre 1 e 12
    compromisso->dia = rand() % 31 + 1;    //dia entre 1 e 31 (ignora dias inválidos)
    compromisso->hora = rand() % 24;       //Hora entre 0 e 23
    compromisso->minuto = rand() % 60;     //Minuto entre 0 e 59
    compromisso->duracao = (rand() % 40 + 1) / 10.0; //Duração entre 0.1 e 4 horas
    strcpy(compromisso->nome, compromissos[rand() % num_compromissos]); //Escolhe um compromisso aleatório
}

void gerarEntradaAleatoria(int quantidadeCompromissos) {
    const char *nomes_compromissos[] = {"Reunião", "Consulta Médica", "Almoço", "Treinamento", "Viagem"};
    int num_nomes = sizeof(nomes_compromissos) / sizeof(nomes_compromissos[0]);

    FILE *arquivo = fopen("entrada.csv", "w");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo para escrita.\n");
        return;
    }

    for (int i = 0; i < quantidadeCompromissos; i++) {
        Compromisso compromisso;
        gerarCompromissoAleatorio(&compromisso, nomes_compromissos, num_nomes);
        fprintf(arquivo, "%d;%d;%d;%d;%d;%.1f;%s\n", compromisso.ano, compromisso.mes, compromisso.dia,
                compromisso.hora, compromisso.minuto, compromisso.duracao, compromisso.nome);
    }

    fclose(arquivo);
}

void insertionSort(Compromisso *compromissos, int n, long long *comparacoes) {
    int i, j;
    Compromisso chave;
    for (i = 1; i < n; i++) {
        chave = compromissos[i];
        j = i - 1;

        while (j >= 0 && compromissos[j].ano > chave.ano) {
            compromissos[j + 1] = compromissos[j];
            j = j - 1;
            (*comparacoes)++;
        }
        compromissos[j + 1] = chave;
        (*comparacoes)++;
    }
}

void ordenarPorAnoInsertionSort(Compromisso *compromissos, int n, long long *comparacoes, double *tempo) {
    clock_t inicio = clock();
    insertionSort(compromissos, n, comparacoes);
    clock_t fim = clock();
    *tempo = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
}

void trocar(Compromisso *a, Compromisso *b) {
    Compromisso temp = *a;
    *a = *b;
    *b = temp;
}

void heapify(Compromisso *compromissos, int n, int i, long long *comparacoes) {
    int maior = i;
    int esquerda = 2 * i + 1;
    int direita = 2 * i + 2;

    if (esquerda < n && compromissos[esquerda].ano > compromissos[maior].ano) {
        maior = esquerda;
    }
    (*comparacoes)++;

    if (direita < n && compromissos[direita].ano > compromissos[maior].ano) {
        maior = direita;
    }
    (*comparacoes)++;

    if (maior != i) {
        trocar(&compromissos[i], &compromissos[maior]);
        heapify(compromissos, n, maior, comparacoes);
    }
}

void heapSort(Compromisso *compromissos, int n, long long *comparacoes) {
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(compromissos, n, i, comparacoes);
    }

    for (int i = n - 1; i > 0; i--) {
        trocar(&compromissos[0], &compromissos[i]);
        heapify(compromissos, i, 0, comparacoes);
    }
}

void ordenarPorAnoHeapSort(Compromisso *compromissos, int n, long long *comparacoes, double *tempo) {
    clock_t inicio_tempo = clock();
    heapSort(compromissos, n, comparacoes);
    clock_t fim_tempo = clock();
    *tempo = ((double)(fim_tempo - inicio_tempo)) / CLOCKS_PER_SEC;
}
