#ifndef COMPROMISSO_H
#define COMPROMISSO_H

typedef struct {
    int ano;
    int mes;
    int dia;
    int hora;
    int minuto;
    float duracao;
    char nome[51];
} Compromisso;

void imprimirCompromisso(Compromisso *compromisso);
void gerarCompromissoAleatorio(Compromisso *compromisso, const char *compromissos[], int num_compromissos);
void gerarEntradaAleatoria(int quantidadeCompromissos);
void ordenarPorAnoInsertionSort(Compromisso *compromissos, int n, long long *comparacoes, double *tempo);
void ordenarPorAnoHeapSort(Compromisso *compromissos, int n, long long *comparacoes, double *tempo);

#endif // COMPROMISSO_H
